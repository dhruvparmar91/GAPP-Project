package gapp.model.dao;

import gapp.model.AppStatus;

public interface AppStatusDao {
	public AppStatus saveStatus(AppStatus status);
	public AppStatus getStatus(Integer id);
}
