package gapp.model.dao;

import gapp.model.Program;

public interface ProgramDao {
	
	Program getProgram(Integer id);
	
	Program saveProgram(Program program);
	
	void removeProgram(Program program);
	
	

}
