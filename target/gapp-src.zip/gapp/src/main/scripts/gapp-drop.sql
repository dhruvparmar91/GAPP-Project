drop table appStatuses, add_fields, add_values, degrees, applications, departments, programs, roles, users CASCADE;
drop sequence hibernate_sequence;